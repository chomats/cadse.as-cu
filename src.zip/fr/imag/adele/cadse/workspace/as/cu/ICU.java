package fr.imag.adele.cadse.workspace.as.cu;


/**

*/
public interface ICU {

	/**
	    @generated
	*/
	String AS_ID = "AS.Workspace.CU";

}
