package fr.imag.adele.cadse.core.attribute;


public interface StringAttributeType extends IAttributeType<String> {

}
