package fr.imag.adele.cadse.core.attribute;

import java.util.Date;

public interface DateAttributeType extends IAttributeType<Date> {

}
