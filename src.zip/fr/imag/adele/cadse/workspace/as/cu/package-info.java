

@PackageInfo(version="1.0.0", requirePackages={})
package fr.imag.adele.cadse.workspace.as.cu;

import fr.imag.adele.packageinfo.PackageInfo;
