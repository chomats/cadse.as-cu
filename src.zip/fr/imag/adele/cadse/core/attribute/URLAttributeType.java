package fr.imag.adele.cadse.core.attribute;

import java.net.URL;

public interface URLAttributeType extends IAttributeType<URL> {

}
