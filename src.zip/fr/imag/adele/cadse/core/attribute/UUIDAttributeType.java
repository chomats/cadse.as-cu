package fr.imag.adele.cadse.core.attribute;

import fr.imag.adele.cadse.core.CompactUUID;

public interface UUIDAttributeType extends IAttributeType<CompactUUID> {

}
