/* 
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package fr.imag.adele.cadse.core.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


/**
 * A specialized map implementation that is optimized for a small set of object
 * keys.
 * 
 * Implemented as a single array that alternates keys and values.
 */
public class ObjectMap<K,V> implements Map<K, V> {

	// 8 attribute keys, 8 attribute values
	/** The Constant DEFAULT_SIZE. */
	protected static final int DEFAULT_SIZE = 16;
	
	/** The Constant GROW_SIZE. */
	protected static final int GROW_SIZE = 10;
	
	/** The count. */
	protected int count = 0;
	
	/** The elements. */
	protected Object[] elements = null;

	/**
	 * Creates a new object map of default size.
	 */
	public ObjectMap() {
		this(DEFAULT_SIZE);
	}

	/**
	 * Creates a new object map.
	 * 
	 * @param initialCapacity
	 *            The initial number of elements that will fit in the map.
	 */
	public ObjectMap(int initialCapacity) {
		if (initialCapacity > 0)
			elements = new Object[Math.max(initialCapacity * 2, 0)];
	}

	/**
	 * Creates a new object map of the same size as the given map and populate
	 * it with the key/attribute pairs found in the map.
	 * 
	 * @param map
	 *            The entries in the given map will be added to the new map.
	 */
	public ObjectMap(Map map) {
		this(map.size());
		putAll(map);
	}

	/**
	 * Clear.
	 * 
	 * @see Map#clear()
	 */
	public void clear() {
		elements = null;
		count = 0;
	}

	/**
	 * Clone.
	 * 
	 * @return the object
	 * 
	 * @see java.lang.Object#clone()
	 */
	@Override
	public Object clone() {
		return new ObjectMap(this);
	}

	/**
	 * Contains key.
	 * 
	 * @param key
	 *            the key
	 * 
	 * @return true, if contains key
	 * 
	 * @see Map#containsKey(java.lang.Object)
	 */
	public boolean containsKey(Object key) {
		if (elements == null || count == 0)
			return false;
		for (int i = 0; i < elements.length; i = i + 2)
			if (elements[i] != null && elements[i].equals(key))
				return true;
		return false;
	}

	/**
	 * Contains value.
	 * 
	 * @param value
	 *            the value
	 * 
	 * @return true, if contains value
	 * 
	 * @see Map#containsValue(java.lang.Object)
	 */
	public boolean containsValue(Object value) {
		if (elements == null || count == 0)
			return false;
		for (int i = 1; i < elements.length; i = i + 2)
			if (elements[i] != null && elements[i].equals(value))
				return true;
		return false;
	}

	/**
	 * Entry set.
	 * 
	 * @return the set< map. entry< k, v>>
	 * 
	 * @see Map#entrySet() This implementation does not conform properly to the
	 *      specification in the Map interface. The returned collection will not
	 *      be bound to this map and will not remain in sync with this map.
	 */
	public Set<Map.Entry<K, V>> entrySet() {
		return toHashMap().entrySet();
	}

	/**
	 * See Object#equals.
	 * 
	 * @param o
	 *            the o
	 * 
	 * @return true, if equals
	 */
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Map))
			return false;
		Map other = (Map) o;
		//must be same size
		if (count != other.size())
			return false;

		//keysets must be equal
		if (!keySet().equals(other.keySet()))
			return false;

		//values for each key must be equal
		for (int i = 0; i < elements.length; i = i + 2) {
			if (elements[i] != null && (!elements[i + 1].equals(other.get(elements[i]))))
				return false;
		}
		return true;
	}

	/**
	 * Gets the.
	 * 
	 * @param key
	 *            the key
	 * 
	 * @return the V
	 * 
	 * @see Map#get(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public V get(Object key) {
		if (elements == null || count == 0)
			return null;
		for (int i = 0; i < elements.length; i = i + 2)
			if (elements[i] != null && elements[i].equals(key))
				return (V) elements[i + 1];
		return null;
	}

	/**
	 * The capacity of the map has been exceeded, grow the array by GROW_SIZE to
	 * accommodate more entries.
	 */
	protected void grow() {
		Object[] expanded = new Object[elements.length + GROW_SIZE];
		System.arraycopy(elements, 0, expanded, 0, elements.length);
		elements = expanded;
	}

	/**
	 * See Object#hashCode.
	 * 
	 * @return the int
	 */
	@Override
	public int hashCode() {
		int hash = 0;
		for (int i = 0; i < elements.length; i = i + 2) {
			if (elements[i] != null) {
				hash += elements[i].hashCode();
			}
		}
		return hash;
	}

	/**
	 * Checks if is empty.
	 * 
	 * @return true, if checks if is empty
	 * 
	 * @see Map#isEmpty()
	 */
	public boolean isEmpty() {
		return count == 0;
	}

	/**
	 * Key set.
	 * 
	 * @return the set< k>
	 * 
	 * @see Map#keySet() This implementation does not conform properly to the
	 *      specification in the Map interface. The returned collection will not
	 *      be bound to this map and will not remain in sync with this map.
	 */
	@SuppressWarnings("unchecked")
	public Set<K>  keySet() {
		Set<K>  result = new HashSet<K> (size());
		for (int i = 0; i < elements.length; i = i + 2) {
			if (elements[i] != null) {
				result.add((K)elements[i]);
			}
		}
		return result;
	}

	/**
	 * Put.
	 * 
	 * @param key
	 *            the key
	 * @param value
	 *            the value
	 * 
	 * @return the V
	 * 
	 * @see Map#put(java.lang.Object, java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public V put(K key, V value) {
		if (key == null)
			throw new NullPointerException();
		if (value == null)
			return remove(key);

		// handle the case where we don't have any attributes yet
		if (elements == null)
			elements = new Object[DEFAULT_SIZE];
		if (count == 0) {
			elements[0] = key;
			elements[1] = value;
			count++;
			return null;
		}

		int emptyIndex = -1;
		// replace existing value if it exists
		for (int i = 0; i < elements.length; i += 2) {
			if (elements[i] != null) {
				if (elements[i].equals(key)) {
					Object oldValue = elements[i + 1];
					elements[i + 1] = value;
					return (V) oldValue;
				}
			} else if (emptyIndex == -1) {
				// keep track of the first empty index
				emptyIndex = i;
			}
		}
		// this will put the emptyIndex greater than the size but
		// that's ok because we will grow first.
		if (emptyIndex == -1)
			emptyIndex = count * 2;

		// otherwise add it to the list of elements.
		// grow if necessary
		if (elements.length <= (count * 2))
			grow();
		elements[emptyIndex] = key;
		elements[emptyIndex + 1] = value;
		count++;
		return null;
	}

	/**
	 * Put all.
	 * 
	 * @param map
	 *            the map
	 * 
	 * @see Map#putAll(java.util.Map)
	 */
	public void putAll(Map<? extends K, ? extends V> map) {
		for (Iterator<? extends K> i = map.keySet().iterator(); i.hasNext();) {
			K key = i.next();
			V value = map.get(key);
			put(key, value);
		}
	}
	

	
	/**
	 * Removes the.
	 * 
	 * @param key
	 *            the key
	 * 
	 * @return the V
	 * 
	 * @see Map#remove(java.lang.Object)
	 */
	@SuppressWarnings("unchecked")
	public V remove(Object key) {
		if (elements == null || count == 0)
			return null;
		for (int i = 0; i < elements.length; i = i + 2) {
			if (elements[i] != null && elements[i].equals(key)) {
				elements[i] = null;
				Object result = elements[i + 1];
				elements[i + 1] = null;
				count--;
				return (V) result;
			}
		}
		return null;
	}

	/**
	 * Size.
	 * 
	 * @return the int
	 * 
	 * @see Map#size()
	 */
	public int size() {
		return count;
	}

//	/* (non-Javadoc
//	 * Method declared on IStringPoolParticipant
//	 */
//	public void shareStrings(StringPool set) {
//		//copy elements for thread safety
//		Object[] array = elements;
//		if (array == null)
//			return;
//		for (int i = 0; i < array.length; i++) {
//			Object o = array[i];
//			if (o instanceof String)
//				array[i] = set.add((String) o);
//			if (o instanceof IStringPoolParticipant)
//				((IStringPoolParticipant) o).shareStrings(set);
//		}
//	}

	/**
 * Creates a new hash map with the same contents as this map.
 * 
 * @return the hash map< k, v>
 */
	@SuppressWarnings("unchecked")
	private HashMap<K, V> toHashMap() {
		HashMap<K, V> result = new HashMap<K, V>(size());
		for (int i = 0; i < elements.length; i = i + 2) {
			if (elements[i] != null) {
				result.put((K)elements[i], (V)elements[i + 1]);
			}
		}
		return result;
	}

	/**
	 * Values.
	 * 
	 * @return the collection< v>
	 * 
	 * @see Map#values() This implementation does not conform properly to the
	 *      specification in the Map interface. The returned collection will not
	 *      be bound to this map and will not remain in sync with this map.
	 */
	@SuppressWarnings("unchecked")
	public Collection<V> values() {
		Set<V> result = new HashSet<V>(size());
		for (int i = 1; i < elements.length; i = i + 2) {
			if (elements[i] != null) {
				result.add((V) elements[i]);
			}
		}
		return result;
	}

	
}
