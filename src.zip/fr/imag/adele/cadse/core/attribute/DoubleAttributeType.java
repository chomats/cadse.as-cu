package fr.imag.adele.cadse.core.attribute;

public interface DoubleAttributeType extends IAttributeType<Double> {

}
