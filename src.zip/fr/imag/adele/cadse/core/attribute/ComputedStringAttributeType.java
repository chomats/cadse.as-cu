package fr.imag.adele.cadse.core.attribute;

public interface ComputedStringAttributeType extends StringAttributeType {

	abstract void setScript(IComputedAttribute script);

}