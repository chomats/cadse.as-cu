package fr.imag.adele.cadse.core.delta;

import fr.imag.adele.cadse.core.internal.delta.InternalWLWCOperation;

public interface CreateOperation extends InternalWLWCOperation {

}