package fr.imag.adele.cadse.core.internal.delta;

public interface InternalSetAttributeOperation {

	void setCurrentValue(Object newValue);

	void setPrecCurrentValue(Object currentValue);

}