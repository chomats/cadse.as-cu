package fr.imag.adele.cadse.core.attribute;

public interface IntegerAttributeType extends IAttributeType<Integer> {

}
